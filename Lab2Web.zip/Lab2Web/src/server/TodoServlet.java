package server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Servlet implementation class TodoServlet
 */
@WebServlet(name="Lab2 Servlet",
description = "Todo servlet created by Denzel Young",
urlPatterns = {"/TodoServlet"})

public class TodoServlet extends HttpServlet{
	private static ConcurrentHashMap<Integer,String> myMap = new ConcurrentHashMap<>();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TodoServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String command = null;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<body>");
		out.println("<h1><center>Welcome to the website version of my Todo system </center></h1>");
		out.println("<h2>A few things first: </h2>");
		out.println("<p>Keep a space between your parameters<br>");
		out.println("<p>Enter an integer for id<br>");
		out.println("<p>Enclose your todo message with quotations</p>");
		out.println("<p>------------------------------------------</p>");
		out.println("<p>Please enter a command listed below</p>");
		out.println("<ul>");
		out.println("<li>POST [id] [todo message]</li>");
		out.println("<li>GET [id]</li>");
		out.println("<li>GET</li>");
		out.println("<li>DELETE [id]</li>");
		out.println("<li>PUT [id] [todo message]</li>");
		out.println("</ul>");
		
		out.println("<form method='GET' action='htmlform/TodoServlet'>"); 
    	out.println("<p>Command <input type='text' name='command'</p>");
    	out.println("<p><input type='submit' value='Submit' name='B1'></p>");
    	out.println("</form>");
		
    	String command2 = request.getParameter(command);
		if (command2.toUpperCase().startsWith("GET"))
		{
			myMap.toString();
		}
		else if (command2.toUpperCase().startsWith("GET "))
		{
			String id_str = command2.substring(4);
			int id = Integer.parseInt(id_str);
			myMap.get(id);
		}
		else if (command2.toUpperCase().startsWith("POST"))
		{
			//Parse out the int, then the message which SHOULD be in quotations
			String id_str = null;
			String message = null;
			int id_length = 0;
			int id = 0;
			
			for (char ch : command2.toCharArray())
			{
				if (Character.isDigit(ch))
				{
					while (Character.isDigit(ch))
					{
						id_str += ch;
						id_length++;
					}
					break;
				}
			}
			
			message = command2.substring((5 + id_length), (command.length() - 1));
			if (myMap.get(id) != null)
			{
				System.out.println("This ID is taken");
			}
			else
			{
				myMap.put(id, message);
			}
		}
		else if (command2.toUpperCase().startsWith("DELETE"))
		{
			//Parse the int, delete that entry
			String id_str = command2.substring(7);
			int id = Integer.parseInt(id_str);
			myMap.remove(id);
		}
		else if (command2.toUpperCase().startsWith("PUT"))
		{
			//Same as POST, but overwrite the current message if there is one.
			String id_str = null;
			String message = null;
			int id_length = 0;
			int id = 0;
			
			for (char ch : command2.toCharArray())
			{
				if (Character.isDigit(ch))
				{
					while (Character.isDigit(ch))
					{
						id_str += ch;
						id_length++;
					}
					break;
				}
			}
			
			message = command2.substring((5 + id_length), (command2.length() - 1));
			myMap.put(id, message);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
