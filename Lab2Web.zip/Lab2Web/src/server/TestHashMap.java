package server;

import java.lang.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TestHashMap {
	//Generates a ConcurrentHashMap of integer, string pairs
	private static ConcurrentHashMap<Integer,String> myMap = new ConcurrentHashMap<>();
	
	//Posts a message without overwriting a currently existing message
	public String postMessage(int id, String msg)
	{
		if (!myMap.containsKey(id))
		{
			return myMap.put(id, msg);
		}
		else
		{
			return "Sorry, that id is taken.";
		}
	}
	
	//Returns the message at the given ID.
	public String getMessage(int id)
	{
		return myMap.get(id);
	}
	
	//Returns all messages and their corresponding keys.
	//Overloaded version of my previous getMessage class
	public void getMessage()
	{
		myMap.toString();
	}
	
	//Removes a message from an ID.
	public void deleteMessage(int id)
	{
		if (myMap.containsKey(id) && myMap.get(id) != null)
		{
			myMap.put(id, "");
		}
		else
		{
				System.out.println("There is no message at that location!");
		}
	}
	
	//Same as POST, but will overwrite a message if one is there.
	public void putMessage(int id, String msg)
	{
		myMap.put(id, msg);
	}
}
