package client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class TodoClient extends TestHashMap {

	public static void main(String args[]) {
		//Print menu here
		//Take input and send to servlet
		boolean leaveApp = false;
		Scanner in = new Scanner(System.in);
		//While loop keeps the app open as long as "Exit" isn't entered by the user
		while (!leaveApp)
		{
			System.out.println("Thank you for using this basic Todo system");
			System.out.println("Please enter one of the following commands:");
			System.out.println("*For [id], please enter an integer");
			System.out.println("*For ['your message'], please enter a string with double quotations.");
			System.out.println("*Use a space between each parameter");
			System.out.println("POST [id] ['your message']");
			System.out.println("GET");
			System.out.println("GET [id]");
			System.out.println("DELETE [id]");
			System.out.println("PUT [id] ['your message']");
			System.out.println("EXIT");
			String command = in.nextLine();

			//Read from Servlet
			if (command.toUpperCase().startsWith("GET"))
			{
				try {
					//If the command is longer than 4 characters, we can deduce
					//that the client entered GET plus an ID. This if statement
					//parses out the ID and stores it.
					//It initializes as null so we can tell the difference between
					//GET [ID] and GET commands
					String id_str = null;
					if (command.length() > 4)
					{
						id_str = command.substring(4, command.length());
					}
					System.out.println("Making GET call");
					String request        = "http://localhost:8080/Lab2Web/TodoServlet?id=" + id_str;
					URL    url            = new URL( request );
					HttpURLConnection conn= (HttpURLConnection) url.openConnection();   

					conn.setInstanceFollowRedirects( false );
					conn.setRequestMethod( "GET" );
					conn.setUseCaches( false );

					BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					String next_record = null;
					while ((next_record = reader.readLine()) != null) {
						System.out.println(next_record);
					}
				} catch (IOException e) {
					throw new RuntimeException("Please try again. \n" + e);
				}
			}
			else if (command.toUpperCase().startsWith("POST") || command.toUpperCase().startsWith("PUT")
					|| command.toUpperCase().startsWith("DELETE"))
			{
				try {
					System.out.println("Making POST call");
					// Parse the URL
					String urlParameters  = "param1=a&param2=b&param3=c";
					byte[] postData       = urlParameters.getBytes( StandardCharsets.UTF_8 );
					int    postDataLength = postData.length;
					String request        = "http://localhost:8080/Lab2Web/TodoServlet?id=";
					URL    url            = new URL( request );
					HttpURLConnection conn= (HttpURLConnection) url.openConnection();   

					conn.setDoOutput( true );
					conn.setInstanceFollowRedirects( false );
					conn.setRequestMethod( "POST" );
					conn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded"); 
					conn.setRequestProperty( "charset", "utf-8");
					conn.setRequestProperty( "Content-Length", Integer.toString( postDataLength ));
					conn.setUseCaches( false );
					try( DataOutputStream wr = new DataOutputStream( conn.getOutputStream())) {
						wr.write( postData );
					}	


					BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					String next_record = null;
					while ((next_record = reader.readLine()) != null) {
						System.out.println(next_record);
					}
				} catch (IOException e) {
					throw new RuntimeException("Please try again. \n" + e);
				}
			}

			else if(command.toUpperCase().startsWith("EXIT"))
			{
				leaveApp = true;
			}
			else
			{
				System.out.println("Invalid command");
			}
		}
	}
}